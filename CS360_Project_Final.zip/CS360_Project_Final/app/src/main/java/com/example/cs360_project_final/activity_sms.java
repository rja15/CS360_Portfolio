/*
@author raymond.agosto1@snhu.edu
This screen is meant to enable SMS notification for an item reaching 0 QTY
 */
package com.example.cs360_project_final;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import static android.content.Context.NOTIFICATION_SERVICE;
import android.app.NotificationChannel;
import android.app.NotificationManager;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class activity_sms extends AppCompatActivity
{

//    private static final String CHANNEL_ID = "channel1";
    ImageButton buttonSignIn;
    ImageButton buttonInventory;
    Button buttonDeny;
    Button buttonApprove;

    @SuppressLint("MissingInflatedId")  //does not like "R.id.btn_inventory"
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms);

//        private void createNotificationChannel() {
//        // Create the NotificationChannel, but only on API 26+ because
//        // the NotificationChannel class is not in the Support Library.
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            CharSequence name = getString(R.string.channel_name);
//            String description = getString(R.string.channel_description);
//            int importance = NotificationManager.IMPORTANCE_DEFAULT;
//            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
//            channel.setDescription(description);
//            // Register the channel with the system; you can't change the importance
//            // or other notification behaviors after this.
//            NotificationManager notificationManager = getSystemService(NotificationManager.class);
//            notificationManager.createNotificationChannel(channel);
//        }
//    }

//        NotificationCompat.Builder builder = new NotificationCompat.Builder(this,)
//                .setSmallIcon(R.drawable.notification_icon)
//                .setContentTitle("smsEnabled")
//                .setContentText("SMS notification enabled")
//                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

//        //approve and access permissions
//        buttonApprove.setOnClickListener(new View.OnClickListener()
//        {
//            @Override
//            public void onClick(View v)
//            {
//
//            }
//        });

        //switch to inventory screen
        buttonInventory = (ImageButton) findViewById(R.id.btn_inventory);
        buttonInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentInventory = new Intent(activity_sms.this, activity_inventory.class);
                startActivity(intentInventory);
            }
        });

        //switch to sign in screen / sign out
        buttonSignIn = (ImageButton) findViewById(R.id.btn_sign_in);
        buttonSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentSignIn = new Intent(activity_sms.this, MainActivity.class);
                startActivity(intentSignIn);
            }
        });

        //toast message for deny
        buttonDeny = (Button) findViewById(R.id.btn_deny);
        buttonDeny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(activity_sms.this,"No Change",Toast.LENGTH_SHORT).show();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}