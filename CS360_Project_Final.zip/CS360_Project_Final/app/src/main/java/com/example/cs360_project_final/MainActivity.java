/*
@author raymond.agosto1@snhu.edu
Main activity is sign in screen that leads to inventory manager. First time user adds data through
text fields, hits create account, then helper classes put into SQLite database. Sign In button moves to Inventory Screen.
 */
package com.example.cs360_project_final;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{

    Button btn_sign_in;
    Button btn_new_account;
    EditText et_username_input;
    EditText et_password_input;

    UserBaseHelper userBaseHelper;  //obj of class that prepares statements for SQL

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //assign GUI elements to variables
        btn_sign_in = (Button) findViewById(R.id.btn_sign_in);
        btn_new_account = (Button) findViewById(R.id.btn_new_account);
        et_username_input = (EditText) findViewById(R.id.et_item_id_input);
        et_password_input = (EditText) findViewById(R.id.et_password_input);

        userBaseHelper = new UserBaseHelper(MainActivity.this);

        //sign in and switch to inventory screen
        btn_sign_in.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //check username and password against those in database,
                //if valid, proceed to next intent, else, toast an error message
                Intent intentInventory = new Intent(MainActivity.this, activity_inventory.class);
                startActivity(intentInventory);
            }
        });

        //makes object that holds user data, makes object that prepares into sql statement, then sends to db
        btn_new_account.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                UserModel userModel;
                try
                {
                 userModel = new UserModel(-1, et_username_input.getText().toString(), et_password_input.getText().toString()); //creates obj and populates with input data
                 Toast.makeText(MainActivity.this, userModel.toString(), Toast.LENGTH_SHORT).show();    //FIXME: TELLS USER WHAT GOT ADDED IF ADDED

                }
                catch (Exception e)
                {
                    Toast.makeText(MainActivity.this, "Error Creating User", Toast.LENGTH_SHORT).show();
                    userModel = new UserModel(-1, "error", "error");   //make a user with default values to indicate bad data
                }
                
                userBaseHelper = new UserBaseHelper(MainActivity.this); //prepares sql
                boolean success = userBaseHelper.addOne(userModel);             //sends to db
                Toast.makeText(MainActivity.this, "Success: " + success, Toast.LENGTH_SHORT).show();

            }
            
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });
    }
}