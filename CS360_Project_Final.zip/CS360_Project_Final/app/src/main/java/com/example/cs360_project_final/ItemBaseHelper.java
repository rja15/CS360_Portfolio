/*
@author raymond.agosto1@snhu.edu
This class creates SQLite table, and translates each new item with data into a new row on the database.
 */
package com.example.cs360_project_final;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class ItemBaseHelper extends SQLiteOpenHelper
{
    public static final String ITEM_TABLE = "ITEM_TABLE";
    public static final String COLUMN_ITEM_ID = "ITEM_ID";
    public static final String COLUMN_ITEM_NAME = "ITEM_NAME";
    public static final String COLUMN_ITEM_QTY = "ITEM_QTY";

    public ItemBaseHelper(@Nullable Context context)
    {
        super(context, "item.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String createTableStatement = "CREATE TABLE " + ITEM_TABLE + " (" + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_ITEM_NAME + " TEXT, " + COLUMN_ITEM_QTY + " INT)";

        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {

    }

    public boolean addOne(ItemModel itemModel)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_ITEM_ID, itemModel.getItemID());
        cv.put(COLUMN_ITEM_NAME, itemModel.getItemName());
        cv.put(COLUMN_ITEM_QTY, itemModel.getItemQty());

        long insert = db.insert(ITEM_TABLE, null, cv);
        if(insert == -1)
        {
            return false;
        }
        return true;
    }

    public List<ItemModel> getInventory()
    {
        List<ItemModel> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " + ITEM_TABLE;

//        SQLiteDatabase db = this.getWritableDatabase();   //if we wanted to write, update, delete
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);   //cursor = result set, the return type; docs say null can be selectArg
        if (cursor.moveToFirst()) //if there are results, "if a first result can be moved to"
        {
            //loop through the cursor and create new item objects. Put them into the return list.
            do
            {
                int itemID = cursor.getInt(0);  // danger if unknown data type in column
                String itemName = cursor.getString(1);
                int itemQty = cursor.getInt(2);

                ItemModel newItem = new ItemModel(itemID, itemName, itemQty);
                returnList.add(newItem);
            }
            while(cursor.moveToNext());    //as long as there are new lines
//            while(cursor.moveToFirst());  //causes infinite loop

        }
        else
        {
            //falure. do not add anything to list.
        }

        cursor.close(); //close connection to the result set
        db.close();     //open up for others to use

        return returnList;
    }

    public boolean deleteOne(ItemModel itemModel)
    {
        //find item in databaase; if it is found, delete and return a true, otherwise ret false
        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = "DELETE FROM " + ITEM_TABLE + " WHERE " + COLUMN_ITEM_ID + " = " + itemModel.getItemID();

        Cursor cursor = db.rawQuery(queryString, null);
        if(cursor.moveToFirst())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}
