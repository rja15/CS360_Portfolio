/*
@author raymond.agosto1@snhu.edu
Inventory activity is what user sees after signin. User can view the items, add items, and delete
by clicking individual items. Navigation buttons on the bottom from left to right: login screen,
inventory screen, and SMS notification center screen
 */
package com.example.cs360_project_final;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class activity_inventory extends AppCompatActivity {

    ImageButton buttonSms;  //nav, bottom right
    ImageButton buttonSignIn;   //nav, bottom left
    ListView lv_itemList;
    EditText et_itemID;
    EditText et_itemName;
    EditText et_itemQty;
    Button btn_addItem;
    ArrayAdapter itemArrayAdapter;  //not originally up here but helps for starting already looking at database
    ItemBaseHelper itemBaseHelper; //creates db table for items and manages sql statements


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        //assign GUI elements to variables
        lv_itemList = findViewById(R.id.lv_itemList);
        et_itemID = (EditText) findViewById(R.id.et_item_id_input);
        et_itemName = (EditText) findViewById(R.id.et_item_name_input);
        et_itemQty = (EditText) findViewById(R.id.et_item_qty_input);
        btn_addItem = (Button) findViewById(R.id.btn_add_item);

        itemBaseHelper = new ItemBaseHelper(activity_inventory.this);
        itemArrayAdapter = new ArrayAdapter<ItemModel>(activity_inventory.this, android.R.layout.simple_list_item_1, itemBaseHelper.getInventory());    //facilitates db data to be displayed

        lv_itemList.setAdapter(itemArrayAdapter);

        //button listeners for the add and view items buttons
        btn_addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ItemModel itemModel;
                try {
                    itemModel = new ItemModel(-1, et_itemName.getText().toString(), Integer.parseInt(et_itemQty.getText().toString())); //creates obj and populates with input data
                    Toast.makeText(activity_inventory.this, itemModel.toString(), Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(activity_inventory.this, "Error Adding Item", Toast.LENGTH_SHORT).show();
                    itemModel = new ItemModel(-1, "error", 0);   //make an item with default values to indicate bad add
                }
//                      context is reference to app. this would be current method, MainActivity.this would be 1 level higher
                ItemBaseHelper itemBaseHelper = new ItemBaseHelper(activity_inventory.this);

                boolean success = itemBaseHelper.addOne(itemModel); //check whether adding item was successful

                Toast.makeText(activity_inventory.this, "Success" + success, Toast.LENGTH_SHORT).show();

//                FIXME: put repetitive lines into method
                itemArrayAdapter = new ArrayAdapter<ItemModel>(activity_inventory.this, android.R.layout.simple_list_item_1, itemBaseHelper.getInventory());
                lv_itemList.setAdapter(itemArrayAdapter);
            }
        });

        lv_itemList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ItemModel clickedItem = (ItemModel) parent.getItemAtPosition(position); //we know ItemModel in db so safe to assume that is what will return
                itemBaseHelper.deleteOne(clickedItem);                                  //removes the item
                ShowItemsOnListView(itemBaseHelper);                                    //updates the viewed inventory
                Toast.makeText(activity_inventory.this, "Deleted" + clickedItem.toString(), Toast.LENGTH_SHORT).show(); //confirms action
            }
        });

        //switch to sms screen
        buttonSms = (ImageButton) findViewById(R.id.btn_sms);
        buttonSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentSMS = new Intent(activity_inventory.this, activity_sms.class); //Changing the intent, moving from old to new activity
                startActivity(intentSMS);
            }
        });

        //switch to sign in screen / sign out
        buttonSignIn = (ImageButton) findViewById(R.id.btn_sign_in);
        buttonSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentSignIn = new Intent(activity_inventory.this, MainActivity.class);
                startActivity(intentSignIn);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void ShowItemsOnListView(ItemBaseHelper itemBaseHelper)
    {
        itemBaseHelper = new ItemBaseHelper(activity_inventory.this);
        itemArrayAdapter = new ArrayAdapter<ItemModel>(activity_inventory.this, android.R.layout.simple_list_item_1, itemBaseHelper.getInventory());
    }
}