/*
@author raymond.agosto1@snhu.edu
This class contains the data for items
 */
package com.example.cs360_project_final;

public class ItemModel
{

    private int itemID;
    private String itemName;
    private int itemQty;

    public ItemModel(int itemID, String itemName, int itemQty) {
        this.itemID = itemID;
        this.itemName = itemName;
        this.itemQty = itemQty;
    }

    public ItemModel()
    {

    }

    @Override
    public String toString() {
        return "ItemModel{" +
                "itemID=" + itemID +
                ", itemName='" + itemName + '\'' +
                ", itemQty=" + itemQty +
                '}';
    }

    public int getItemID() {
        return itemID;
    }

    public void setItemID(int itemID) {
        this.itemID = itemID;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getItemQty() {
        return itemQty;
    }

    public void setItemQty(int itemQty) {
        this.itemQty = itemQty;
    }
}
