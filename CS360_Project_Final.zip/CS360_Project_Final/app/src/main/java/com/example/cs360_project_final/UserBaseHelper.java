/*
@author raymond.agosto1@snhu.edu
This class creates SQLite table, and translates each new user with data into a new row on the database.
 */
package com.example.cs360_project_final;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class UserBaseHelper extends SQLiteOpenHelper
{
    public static final String USER_TABLE = "USER_TABLE";
    public static final String COLUMN_USER_ID = "USER_ID";
    public static final String COLUMN_USERNAME = "USERNAME";
    public static final String COLUMN_USER_PASSWORD = "USER_PASSWORD";

    public UserBaseHelper(@Nullable Context context)
    {
        super(context, "user.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String createTableStatement = "CREATE TABLE " + USER_TABLE + " (" + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USERNAME + " TEXT, " + COLUMN_USER_PASSWORD + " TEXT)";
        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)    //required but not used
    {

    }

    public boolean addOne(UserModel userModel)  //puts a single new user into the database, returns success
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_USER_ID, userModel.getUserId());
        cv.put(COLUMN_USERNAME, userModel.getUserName());
        cv.put(COLUMN_USER_PASSWORD, userModel.getUserPassword());

        long insert = db.insert(USER_TABLE, null, cv);
        if (insert == -1)
        {
            return false;
        }
        return true;
    }
}
